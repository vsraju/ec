<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of MY_Output
 *
 * @author mani
 */
class MY_Output extends CI_Output {

    function nocacheMy() {

        $this->set_header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
        $this->set_header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        $this->set_header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
        $this->set_header('Cache-Control: post-check=0, pre-check=0', FALSE);
        $this->set_header('Pragma: no-cache');
    }

    function nocache(){
    	$this->output->set_header("HTTP/1.0 200 OK");
        $this->output->set_header("HTTP/1.1 200 OK");
        $this->output->set_header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Cache-Control: post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    }

}

/* End of file MY_Output.php */
/* Location: ./application/core/MY_Output.php */