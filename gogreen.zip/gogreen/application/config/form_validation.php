<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
$config = array(
    'loginform' => array(
        array(
            'field' => 'username',
            'label' => 'Username',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'trim|required|xss_clean'
        )
    ),
    // Forgot password in all place Validation
    'forgot_password' => array(
        array(
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'trim|required|valid_email'
        )
    ),
    // Change password in all place except first login Validation
    'change_password' => array(
        array(
            'field' => 'cur_pwd',
            'label' => 'Current Password',
            'rules' => 'trim|required|min_length[6]|max_length[30]|xss_clean'
        ),
        array(
            'field' => 'new_pwd',
            'label' => 'New Password',
            'rules' => 'trim|required|min_length[6]|max_length[30]|matches[conf_pwd]|xss_clean'
        ),
        array(
            'field' => 'conf_pwd',
            'label' => 'Confirm Password',
            'rules' => 'trim|required|min_length[6]|max_length[30]|matches[new_pwd]|xss_clean'
        )
    ),
    'profile' => array(
        array(
            'field' => 'first_name',
            'label' => 'First Name',
            'rules' => 'trim|required|min_length[1]|max_length[100]|xss_clean'
        ),
//        array(
//            'field' => 'last_name',
//            'label' => 'Last Name',
//            'rules' => 'trim|required|min_length[1]|max_length[100]|xss_clean'
//        ),
        array(
            'field' => 'email',
            'label' => 'Email ID',
            'rules' => 'trim|required|valid_email|min_length[1]|max_length[150]|xss_clean'
        ),
        array(
            'field' => 'mobile',
            'label' => 'Mobile No',
            'rules' => 'trim|required|numeric|min_length[10]|max_length[10]|xss_clean'
        ),
    ),
    'commom-data' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'trim|required|min_length[1]|max_length[150]|xss_clean'
        )
    ),
    'blog' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'trim|required|min_length[1]|max_length[150]|xss_clean'
        ),
//        array(
//            'field' => 'url',
//            'label' => 'Url',
//            'rules' => 'trim|required|min_length[1]|max_length[150]|xss_clean'
//        ),
        array(
            'field' => 'description',
            'label' => 'Description',
            'rules' => 'trim|required|min_length[1]|xss_clean'
        ),
    ),
    'pages' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'trim|required|min_length[1]|max_length[150]|xss_clean'
        ),
//        array(
//            'field' => 'url',
//            'label' => 'Url',
//            'rules' => 'trim|required|min_length[1]|max_length[150]|xss_clean'
//        ),
        array(
            'field' => 'description',
            'label' => 'Description',
            'rules' => 'trim|required|min_length[1]|xss_clean'
        ),
    ),
    'testimonial' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'trim|required|min_length[1]|max_length[150]|xss_clean'
        ),
//        array(
//            'field' => 'url',
//            'label' => 'Url',
//            'rules' => 'trim|required|min_length[1]|max_length[150]|xss_clean'
//        ),
        array(
            'field' => 'description',
            'label' => 'Description',
            'rules' => 'trim|required|min_length[1]|max_length[250]|xss_clean'
        ),
    ),
    'cms' => array(
        array(
            'field' => 'description',
            'label' => 'Description',
            'rules' => 'trim|required|min_length[1]|xss_clean'
        ),
    ),
    'websetting' => array(
        array(
            'field' => 'email',
            'label' => 'Email ID',
            'rules' => 'trim|required|valid_email|min_length[1]|max_length[150]|xss_clean'
        ),
        array(
            'field' => 'mobile',
            'label' => 'Mobile No',
            'rules' => 'trim|required|numeric|min_length[10]|max_length[10]|xss_clean'
        ),
        array(
            'field' => 'seo_title',
            'label' => 'seo title',
            'rules' => 'trim|required|min_length[1]|max_length[500]xss_clean'
        ),
        array(
            'field' => 'seo_description',
            'label' => 'seo description',
            'rules' => 'trim|required|min_length[1]|max_length[500]xss_clean'
        ),
        array(
            'field' => 'seo_keywords',
            'label' => 'seo keywords',
            'rules' => 'trim|required|min_length[1]|max_length[500]xss_clean'
        ),
    ),
    'home' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'trim|required|min_length[1]|max_length[250]|xss_clean'
        ),
        array(
            'field' => 'description1',
            'label' => 'Description1',
            'rules' => 'trim|required|min_length[1]|xss_clean'
        ),
        array(
            'field' => 'description2',
            'label' => 'Description2',
            'rules' => 'trim|required|min_length[1]|xss_clean'
        ),
        array(
            'field' => 'description3',
            'label' => 'Description3',
            'rules' => 'trim|required|min_length[1]|xss_clean'
        ),
    ),
    'products' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'trim|required|min_length[1]|max_length[250]|xss_clean'
        ),
        array(
            'field' => 'size',
            'label' => 'size',
            'rules' => 'trim|required|min_length[1]|max_length[250]|xss_clean'
        ),
        array(
            'field' => 'price',
            'label' => 'price',
            'rules' => 'trim|required|min_length[1]|max_length[250]|xss_clean'
        ),
        array(
            'field' => 'stock_status',
            'label' => 'stock status',
            'rules' => 'trim|required|min_length[1]|max_length[20]|xss_clean'
        ),
//        array(
//            'field' => 'small_content',
//            'label' => 'description',
//            'rules' => 'trim|required|max_length[1000]|xss_clean'
//        ),
    ),
    'enquiry' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'trim|required|min_length[1]|max_length[100]|xss_clean'
        ),
        array(
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'trim|required|valid_email|min_length[1]|max_length[150]|xss_clean'
        ),
        array(
            'field' => 'mobile',
            'label' => 'Mobile No',
            'rules' => 'trim|required|numeric|min_length[10]|max_length[10]|xss_clean'
        ),
        array(
            'field' => 'location',
            'label' => 'location',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'message',
            'label' => 'Message',
            'rules' => 'trim|required|min_length[1]|max_length[250]|xss_clean'
        ),
    ),
);
