<!-- header logo: style can be found in header.less -->
<header class="header">
    <a href="<?php echo ADMIN_URL; ?>" class="logo">
        <!-- Add the class icon to your logo image or logo icon to add the margining -->
        <?php // echo $_SERVER['SERVER_NAME']; ?>
        <div class="logo-part-admin">
            <img src="<?php echo site_url(); ?>uploads/logo/logo.png" alt="<?php echo ($_SERVER['SERVER_NAME']); ?>"  />
        </div>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <div class="navbar-right">
            <ul class="nav navbar-nav">
                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="<?php echo ADMIN_URL; ?>profile" class="dropdown-toggle1" data-toggle="dropdown1">
                        <i class="glyphicon glyphicon-user"></i>
                        <span><?php echo $getUser['first_name'] . ' ' . $getUser['last_name']; ?> </span>
                    </a>
                </li>
                <li class="dropdown user user-menu">
                    <a href="<?php echo ADMIN_URL; ?>logout" class="dropdown-toggle" >
                        <i class="glyphicon glyphicon-off"></i>
                        <span>Sign out</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
</header>
