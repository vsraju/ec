<!-- Left side column. contains the logo and sidebar --> 
<aside class="left-side sidebar-offcanvas">                
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->       
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">          
            <li <?php echo ($this->uri->segment(2) == 'profile') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>profile">
                    <img src="<?php echo base_url(); ?>assets/img/icons/Profile.png" alt="" class="icon-image" /> <span>Profile</span>
                </a>
            </li> 
            <li <?php echo ($this->uri->segment(2) == 'changepassword') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>changepassword">
                    <img src="<?php echo base_url(); ?>assets/img/icons/changepwd.png" alt="" class="icon-image" /> <span>Change Password</span>
                </a>
            </li>       
            <li <?php echo ($this->uri->segment(2) == 'home_banners') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>home_banners">
                    <img src="<?php echo base_url(); ?>assets/img/icons/universitydeatils.png" alt="" class="icon-image" /> <span> Home Banners</span>
                </a>
            </li>
            <li <?php echo ($this->uri->segment(2) == 'home_content') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>home_content">
                    <img src="<?php echo base_url(); ?>assets/img/icons/universitydeatils.png" alt="" class="icon-image" /> <span> Home Content</span>
                </a>
            </li>
            <li <?php echo ($this->uri->segment(2) == 'pages') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>pages">
                    <img src="<?php echo base_url(); ?>assets/img/icons/university.png" alt="" class="icon-image" /> <span>  Spirulina Pages</span>
                </a>
            </li>
            <li <?php echo ($this->uri->segment(2) == 'blog') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>blog">
                    <img src="<?php echo base_url(); ?>assets/img/icons/universitydeatils.png" alt="" class="icon-image" /> <span> Blog</span>
                </a>
            </li>	

            <li <?php echo ($this->uri->segment(2) == 'products') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>products">
                    <img src="<?php echo base_url(); ?>assets/img/icons/universitydeatils.png" alt="" class="icon-image" /> <span> Products</span>
                </a>
            </li>

            <li <?php echo ($this->uri->segment(2) == 'product_orders') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>product_orders">
                    <img src="<?php echo base_url(); ?>assets/img/icons/universitydeatils.png" alt="" class="icon-image" /> <span> Product Orders</span>
                </a>
            </li>


<!--            <li <?php echo ($this->uri->segment(2) == 'testimonial') ? 'class="active"' : ''; ?> >
                <a href="<?php echo ADMIN_URL; ?>testimonial">
                    <img src="<?php echo base_url(); ?>assets/img/icons/universitydeatils.png" alt="" class="icon-image" /> <span> Testimonial</span>
                </a>
            </li>				
            <li <?php echo ($this->uri->segment(2) == 'cms') ? 'class="active"' : ''; ?> >
                <a hre<!-- f="<?php echo ADMIN_URL; ?>cms">
                    <img src="<?php echo base_url(); ?>assets/img/icons/universitydeatils.png" alt="" class="icon-image" /> <span> CMS</span>
                </a>
            </li>
            -->




        </ul>

    </section>
    <!-- /.sidebar -->
</aside>