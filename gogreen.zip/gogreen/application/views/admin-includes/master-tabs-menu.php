<!--<div style="margin-top: 15px;">
    <ul class="nav navbar-nav nav-pills"> 
        <li  <?php echo ($this->uri->segment(2) == 'mother_tongue') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>mother_tongue"><i class="fa fa-folder"></i>Mother Tongue</a>
        </li>     

        <li  <?php echo ($this->uri->segment(2) == 'education') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>education"><i class="fa fa-folder"></i>Education</a>
        </li>
        <li  <?php echo ($this->uri->segment(2) == 'occupation') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>occupation"><i class="fa fa-folder"></i>Occupation</a>
        </li>
        <li  <?php echo ($this->uri->segment(2) == 'hobbies') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>hobbies"><i class="fa fa-folder"></i>Hobbies</a>
        </li>
        <li  <?php echo ($this->uri->segment(2) == 'marital_status') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>marital_status"><i class="fa fa-folder"></i>Marital Status</a>
        </li>
        <li  <?php echo ($this->uri->segment(2) == 'physical_status') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>physical_status"><i class="fa fa-folder"></i>Physical Status</a>
        </li>
        <li  <?php echo ($this->uri->segment(2) == 'age') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>age"><i class="fa fa-folder"></i>Age</a>
        </li>
        <li  <?php echo ($this->uri->segment(2) == 'height') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>height"><i class="fa fa-folder"></i>Height</a>
        </li>
        <li  <?php echo ($this->uri->segment(2) == 'weight') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>weight"><i class="fa fa-folder"></i>Weight</a>
        </li>
        <li <?php echo ($this->uri->segment(2) == 'language') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>language"><i class="fa fa-folder"></i>Language</a>
        </li>
    </ul>
</div>
<div class="clearfix"></div>
<div style="margin-top: 15px;">
    <ul class="nav navbar-nav nav-pills">     
        <li  <?php echo ($this->uri->segment(2) == 'religion') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>religion"><i class="fa fa-folder"></i>Religion</a>
        </li>
        <li  <?php echo ($this->uri->segment(2) == 'caste') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>caste"><i class="fa fa-folder"></i>Caste</a>
        </li>      

        <li  <?php echo ($this->uri->segment(2) == 'star') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>star"><i class="fa fa-folder"></i>Star</a>
        </li>

        <li  <?php echo ($this->uri->segment(2) == 'rassi_moonsign') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>rassi_moonsign"><i class="fa fa-folder"></i>Rassi Moonsign</a>
        </li>

        <li <?php echo ($this->uri->segment(2) == 'zodiac') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>zodiac"><i class="fa fa-folder"></i>Zodiac</a>
        </li>

        <li <?php echo ($this->uri->segment(2) == 'gothram') ? 'class="active"' : ''; ?> >
            <a href="<?php echo ADMIN_URL; ?>gothram"><i class="fa fa-folder"></i>Gothram</a>
        </li>

      <li  <?php echo ($this->uri->segment(2) == 'marital_status') ? 'class="active"' : ''; ?> >
    <a href="<?php echo ADMIN_URL; ?>marital_status"><i class="fa fa-folder"></i>Marital Status</a>
</li>
<li  <?php echo ($this->uri->segment(2) == 'physical_status') ? 'class="active"' : ''; ?> >
    <a href="<?php echo ADMIN_URL; ?>physical_status"><i class="fa fa-folder"></i>Physical Status</a>
</li>
<li  <?php echo ($this->uri->segment(2) == 'age') ? 'class="active"' : ''; ?> >
    <a href="<?php echo ADMIN_URL; ?>age"><i class="fa fa-folder"></i>Age</a>
</li>
    </ul>
</div>-->