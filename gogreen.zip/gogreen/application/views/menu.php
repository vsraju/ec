<div class="main-slider">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 padding0">
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <?php if (!empty($bannerData)) { ?>
                            <?php foreach ($bannerData as $key => $value) { ?>
                                <div class="item <?php echo ($key == 0) ? 'active' : ''; ?>">
                                    <img src="<?php echo ($value['image'] != '' && file_exists('./' . $value['image'])) ? base_url() . $value['image'] : NO_IMG_BAN; ?>" alt="68M Hoildays"  style="width:100%;height:600px">
                                </div>                               
                            <?php } ?>
                        <?php } ?>

                        <div class="main-text">
                            <!--------------main-head---------->
                            <div class="col-md-12 ">
                                <div class="main-head">
                                    <ul>

                                        <li>
                                            <a href="javascript.void(0);">
                                                Call Us Today: <?php echo $webData['contact_mobile']; ?>
                                            </a>
                                        </li>
                                        <li><a href="javascript.void(0);">|</a></li>
                                        <li>
                                            <a href="javascript.void(0);">
                                                <?php echo $webData['contact_email']; ?>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!---------------header---------------->
                            <div class="col-md-12">
                                <div class="header">
                                    <div class="col-md-12 col-md-offset-4">
                                        <nav class="navbar">
                                            <div class="container-fluid">
                                                <div class="navbar-header">
                                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                                        <span class="icon-bar"></span>
                                                        <span class="icon-bar"></span>
                                                        <span class="icon-bar"></span> 
                                                    </button>
                                                    <a class="navbar-brand" href="<?php echo base_url(); ?>">
                                                        <img src="<?php echo base_url(); ?><?php echo $webData['logo']; ?>">
                                                    </a>
                                                </div>
                                                <div class="collapse navbar-collapse" id="myNavbar">
                                                    <ul class="nav navbar-nav">
                                                        <li  class="<?php echo ($this->uri->segment(1) == '') ? 'active' : ''; ?>">
                                                            <a href="<?php echo base_url(); ?>">Home</a>
                                                        </li>                                                         
                                                        <li class="<?php echo ($this->uri->segment(1) == 'about-us') ? 'active' : ''; ?>">
                                                            <a href="<?php echo base_url(); ?>about-us">About Us</a>
                                                        </li> 
                                                        <li class="dropdown <?php echo ($this->uri->segment(1) == '') ? 'active' : ''; ?>">
                                                            <a href="javascript:void();" style="cursor:default;">Spirluna</a>
                                                            <ul class="dropdown-menu">
                                                                <?php if (!empty($spirlunaMenuData)) { ?>
                                                                    <?php foreach ($spirlunaMenuData as $key => $value) { ?>
                                                                        <li><a href="<?php echo base_url(); ?><?php echo stripslashes($value['category_url_name']); ?>/<?php echo stripslashes($value['url_name']); ?>/<?php echo stripslashes($value['id']); ?>"><?php echo stripslashes($value['name']); ?></a></li>      
                                                                    <?php } ?>
                                                                <?php } ?>
                                                            </ul>
                                                        </li>
                                                        <li class="<?php echo ($this->uri->segment(1) == 'blog') ? 'active' : ''; ?>"><a href="<?php echo base_url(); ?>blog">Blog</a></li>
                                                        <li class="<?php echo ($this->uri->segment(1) == 'shop') ? 'active' : ''; ?>"><a href="<?php echo base_url(); ?>shop">Shop</a></li>
                                                        <li class="<?php echo ($this->uri->segment(1) == 'cart') ? 'active' : ''; ?>" id="shopping_cartDiv">
                                                            <?php $cartCnt = $this->common->get_cart_product_cnt(); ?>
                                                            <?php if ($cartCnt == 0) { ?>
                                                                <a href="<?php echo base_url(); ?>cart"><?php echo $cartCnt; ?> Cart Items</a>
                                                            <?php } else { ?>
                                                                <a href="<?php echo base_url(); ?>cart"><?php echo $cartCnt; ?> Cart Items</a>
                                                            <?php } ?>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                    </div>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                    </a>
                    <a class="right carousel-control"   href="#carousel-example-generic" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                    </a>
                </div>

            </div>
        </div>
    </div>
</div>
<!-----------------super-green------------------>