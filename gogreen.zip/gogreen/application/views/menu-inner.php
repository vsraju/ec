<style>
    h2 hr{
        margin-bottom: 20px;
        border: 0;
        border-top: 2px solid #dbd4d4;
        width: 100px;
    }
</style>
<div class="container">
    <div class="row">
        <div class="shop-head">
            <div class="col-md-12">
                <div class="main-head">
                    <ul>
                        <li>
                            <a href="javascript.void(0);">
                                Call Us Today: <?php echo $webData['contact_mobile']; ?>
                            </a>
                        </li>
                        <li><a href="javascript.void(0);">|</a></li>
                        <li>
                            <a href="javascript.void(0);">
                                <?php echo $webData['contact_email']; ?>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"></div>
<!----------------main-header----------------->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-9">
            <div class="header-shop">
                <nav class="navbar">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span> 
                            </button>
                            <a class="navbar-brand" href="<?php echo base_url(); ?>">
                                <img src="<?php echo base_url(); ?><?php echo $webData['logo']; ?>">
                            </a>
                        </div>
                        <div class="collapse navbar-collapse" id="myNavbar">
                            <ul class="nav navbar-nav">
                                <li  class="<?php echo ($this->uri->segment(1) == '') ? 'active' : ''; ?>">
                                    <a href="<?php echo base_url(); ?>">Home</a>
                                </li>                                                         
                                <li class="<?php echo ($this->uri->segment(1) == 'about-us') ? 'active' : ''; ?>">
                                    <a href="<?php echo base_url(); ?>about-us">About Us</a>
                                </li> 
                                <li class="dropdown <?php echo ($this->uri->segment(1) == '') ? 'active' : ''; ?>">
                                    <a href="javascript:void();" style="cursor:default;">Spirluna</a>
                                    <ul class="dropdown-menu">
                                        <?php if (!empty($spirlunaMenuData)) { ?>
                                            <?php foreach ($spirlunaMenuData as $key => $value) { ?>
                                                <li><a href="<?php echo base_url(); ?><?php echo stripslashes($value['category_url_name']); ?>/<?php echo stripslashes($value['url_name']); ?>/<?php echo stripslashes($value['id']); ?>"><?php echo stripslashes($value['name']); ?></a></li>      
                                            <?php } ?>
                                        <?php } ?>
                                    </ul>
                                </li>
                                <li class="<?php echo ($this->uri->segment(1) == 'blog') ? 'active' : ''; ?>"><a href="<?php echo base_url(); ?>blog">Blog</a></li>
                                <li class="<?php echo ($this->uri->segment(1) == 'shop') ? 'active' : ''; ?>"><a href="<?php echo base_url(); ?>shop">Shop</a></li>
                                <li class="<?php echo ($this->uri->segment(1) == 'cart') ? 'active' : ''; ?>" id="shopping_cartDiv">
                                    <?php $cartCnt = $this->common->get_cart_product_cnt(); ?>
                                    <?php if ($cartCnt == 0) { ?>
                                        <a href="<?php echo base_url(); ?>cart"><?php echo $cartCnt; ?> Cart Items</a>
                                    <?php } else { ?>
                                        <a href="<?php echo base_url(); ?>cart"><?php echo $cartCnt; ?> Cart Items</a>
                                    <?php } ?>
                                </li>
                            </ul>
                        </div>
                    </div>
            </div>
            </nav>
        </div>
    </div>
</div>
<div class="clearfix"></div>
