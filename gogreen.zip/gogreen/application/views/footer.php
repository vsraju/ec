<!----------------------footer---------------->
<div class="footer">
    <div class="container">
        <div class="row padding-row">
            <div class="col-md-4">
                <div class="footer-texr">
                    <a href="#"><img src="<?php echo base_url(); ?>images/footer-logo.png"></a>
                    <p>Fusce auctor, metus eu ultricies vulputate, sapien nibh faucibus ligula, eget sollicitudin augue risus et dolor. Aenean pellentesque, tortor in cursus</p>
                </div>
            </div>
            <div class="col-md-2">
                <h3>Suport</h3>
                <p>Delivery Zones</p>
                <p>Freight calculator</p>
            </div>
            <div class="col-md-3">
                <h3>Contact Info</h3>
                <p>Evolutionary Health.Org Ltd Po Box 8036</p>
                <p>New Plymouth</p>
                <p>New Zealand</p>
                <p>Phone: 6467511163</p>
                <p>Fax: 646711162</p>
            </div>
            <div class="col-md-3">
                <div class="social">
                    <h3>Get Social</h3>
                    <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-wifi" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                    <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="copy-rights">
            <center>
                <p>Copyright <?php date('Y'); ?> Gogreenorganics | All Rights Reserved | A Division of Evolutionary health .org | Site Design By Flutterhost | Sitemap.</p>
            </center>
        </div>
    </div>
</div>

<!--======= Bootstrap =========-->
<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>

<!--======= Touch Swipe =========-->
<script src="<?php echo base_url(); ?>js/jquery.touchSwipe.min.js"></script>

<!--======= Customize =========-->
<script src="<?php echo base_url(); ?>js/responsive_bootstrap_carousel.js"></script>

<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script>
    window.setTimeout(function () {
        $("#successModal").modal("hide");
    }, 4000);

    function getCart(productId, browserId, divId, productQuantity, purchaseQuantity) {
        //alert(productQuantity);
        var productQuantityVal = productQuantity;
        $("#alert").text('');
        $("#alert").hide();
        var usertype = '<?php echo $this->session->userdata("user_type"); ?>';
        if (usertype != 'admin') {
            $.ajax({
                type: "POST", url: '<?php echo base_url(); ?>cart/set_cart_value', data: "productId=" + productId + "&browserId=" + browserId + "&productQuantity=" + productQuantityVal + "&purchaseQuantity=" + purchaseQuantity,
                complete: function (data) {
                    var op = data.responseText.trim();
                    getCartViewPopup(browserId);
                    $("#alert").text(op);
                    $("#alert").show();
                    $("#successModal").modal("show");
                }
            });
        } else {
            $("#alert").text('You are not authorized to purchase...');
            $("#alert").show();
            $("#successModal").modal("show");
        }
    }

    function getCartViewPopup(browser_id) {
        $.ajax({
            type: "POST", url: '<?php echo site_url(); ?>cart/getCartViewPopup', data: "browser_id=" + browser_id,
            complete: function (data) {
                var op = data.responseText.trim();
                $("#shopping_cartDiv").html(op);
            }
        });
    }

    function deleteCartViewPopup(id, currentUrl) {
        $.ajax({
            type: "POST", url: '<?php echo site_url(); ?>cart/deleteCartView', data: "id=" + id + "&currentUrl" + currentUrl,
            complete: function (data) {
                var op = data.responseText.trim();
                // alert(op);
                getCartViewPopup('<?php echo $this->session->userdata("browser_session_id"); ?>');
            }
        });
    }

</script>
<!-- Modal -->
<div class="modal fade" id="successModal" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">            
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <p  id="alert"></p>
            </div>           
        </div>
    </div>
</div>
</body>
</html>
