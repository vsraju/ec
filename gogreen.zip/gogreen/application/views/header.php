<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!-- Seo Metas-->
        <title><?php echo ($seo_tags['seo_title'] != '') ? stripslashes(str_replace('\n', '', $seo_tags['seo_title'])) : '68 M Holiday'; ?></title>
        <meta content="<?php echo ($seo_tags['seo_description'] != '') ? stripslashes(str_replace('\n', '', $seo_tags['seo_description'])) : '68 M Holiday'; ?>" name="description">
        <meta content="<?php echo ($seo_tags['seo_keywords'] != '') ? stripslashes(str_replace('\n', '', $seo_tags['seo_keywords'])) : '68 M Holiday'; ?>" name="generator">
        <!--  Seo  Metas-->

        <!--  favicon -->
        <link rel="shortcut icon" href="<?php echo base_url(); ?>images/<?php echo $webData['favicon']; ?>" type="image/x-icon">
        <link rel="icon" href="<?php echo base_url(); ?>images/<?php echo $webData['favicon']; ?>" type="image/x-icon">
        <!--  favicon -->

        <!-- Bootstrap -->
        <link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>css/font-awesome.min.css" rel="stylesheet" media="all">
        <link href="<?php echo base_url(); ?>css/responsive_bootstrap_carousel_mega_min.css" rel="stylesheet" media="all">
        <link href="<?php echo base_url(); ?>css/theme.css" rel="stylesheet" media="all">
        <script src="<?php echo base_url(); ?>js/jquery-1.11.3.min.js"></script>

    </head>
    <body>