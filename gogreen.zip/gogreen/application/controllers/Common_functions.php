<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Common_functions extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Common', 'common');
    }

    public function getIndividualDropdownJson() {
        $postArr = $this->input->post();
        $val = $postArr['val'];
        $fName = $postArr['fName'];
        $getRows = $this->common->$fName($val);
        echo json_encode($getRows);
        exit();
    }

    public function getRelatedDropdown() {
        $postArr = $this->input->post();
        $parentVal = $postArr['parentVal'];
        $fName = $postArr['fName'];
        $html = '<option value="" >--Select--</option>';
        if ($parentVal != '' && $fName != '') {
            $getRows = $this->common->$fName($postArr['parentVal']);
            if (!empty($getRows)) {
                foreach ($getRows as $key => $value) {
                    $html .="<option  value=" . $value['id'] . " >" . $value['name'] . "</option>";
                }
            }
        }
        echo $html;
        exit();
    }

    public function getInputVal() {
        $postArr = $this->input->post();
        $parentVal = $postArr['parentVal'];
        $fName = $postArr['fName'];
        $html = '';
        if ($parentVal != '' && $fName != '') {
            $getRow = $this->common->$fName($postArr['parentVal']);
            if (!empty($getRow)) {
                $html = $getRow['country_isd_code'];
            }
        }
        echo $html;
        exit();
    }

    public function getFlagImg() {
        $postArr = $this->input->post();
        $parentVal = $postArr['parentVal'];
        $fName = $postArr['fName'];
        $html = '';
        if ($parentVal != '' && $fName != '') {
            $getRow = $this->common->$fName($postArr['parentVal']);

            if (!empty($getRow)) {
                $flag = strtolower($getRow['country_iso_code']);
                $filePath = './flags/' . $flag . '.png';
                if (is_file($filePath)) {
                    $html = '<image id="flagImg" src="' . base_url() . $filePath . '" />';
                }
            }
        }
        echo $html;
        exit();
    }

    public function getAgeVal() {
        $postArr = $this->input->post();
        $parentVal = $postArr['parentVal'];
        $fName = $postArr['fName'];
        $retVal = $postArr['retVal'];
        $html = '';
        if ($parentVal != '' && $fName != '') {
            $getRow = $this->common->$fName($postArr['parentVal'], $retVal);
            if (!empty($getRow)) {
                $html = $getRow;
            }
        }
        echo $html;
        exit();
    }

    public function getDeleteRowTr() {
        $postArr = $this->input->post();
        $rowId = $postArr['rowId'];
        $fName = $postArr['fName'];
        $prefix = $postArr['prefix'];
        $html = '';
        if ($rowId != '' && $fName != '') {

            $where = array('id' => $rowId);

            switch ($prefix) {
                case "academic":
                    $table = 'tbl_student_academic';
                    $getRow = $this->common->$fName($where, $table);
                    return $getRow;
                    break;
                case "certificate":
                    $table = 'tbl_student_academic';
                    $getRow = $this->common->$fName($where, $table);
                    return $getRow;
                    break;
                case "prefer":
                    $table = 'tbl_student_prefer';
                    $getRow = $this->common->$fName($where, $table);
                    return $getRow;
                    break;
                default:
                    return true;
                    break;
            }
        }
    }

    public function getPfCourseDropdownSumoSelect() {
        $postArr = $this->input->post();
        $parentVal = $postArr['parentVal'];
        $childName = $postArr['childName'];
        $childID = $postArr['childID'];
        $fName = $postArr['fName'];

        $html = '<select class="form-control pratical-dropdown slectBoxCls"  name="' . $childName . '"  id="' . $childID . '" multiple  >';
        if ($parentVal != '' && $fName != '') {
            $getRows = $this->common->$fName($postArr['parentVal']);
            if (!empty($getRows)) {
                foreach ($getRows as $key => $value) {
                    $html .="<option  value=" . $value['id'] . " >" . $value['name'] . "</option>";
                }
            }
        }
        $html .= '</select>';
        $html .= '<script type="text/javascript">'
                // . '$(document).ready(function () {'
                . '$("#' . $childID . '").SumoSelect({csvDispCount: 3, selectAll: true, search: true, searchText: "Search"});'
                //  . ' });'
                . '</script>';

        echo $html;
        exit();
    }

}
