<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Common
 *
 * @author Innasoft
 */
class Common extends CI_Model {

    public $banner_table = 'tbl_home_banners';
    public $cart_products = 'tbl_cart_products';

    public function __construct() {
        parent::__construct();

        date_default_timezone_set('Asia/Kolkata');
        if ($this->session->userdata("browser_session_id") == '') {
            $uniqueId = uniqid($_SERVER['REMOTE_ADDR'], TRUE);
            $this->session->set_userdata("browser_session_id", md5($uniqueId));
        }
        $this->load->model('EmailSms', 'email_sms');
    }

    public function get_cart_product() {
        $this->db->select("*");
        $this->db->from($this->cart_products);
        $this->db->where('browser_id', $this->session->userdata("browser_session_id"));
        $this->db->order_by('id', 'desc');
        $query = $this->db->get();
        //echo $his->db->last_query();
        $result = $query->result_array();
        return $result;
    }

    public function get_cart_product_cnt() {
        $this->db->from($this->cart_products);
        $this->db->where('browser_id', $this->session->userdata("browser_session_id"));
        $this->db->where('status', 1);
        $resultCnt = $this->db->count_all_results();
        return $resultCnt;
    }

    public function get_SEO_page($tablename, $where) {
        $this->db->select("seo_title,seo_description,seo_keywords");
        $this->db->from($tablename);
        $this->db->where($where);
        $query = $this->db->get();
        $result = $query->row_array();
        return $result;
    }

    public function time_ago($date) {

        if (empty($date)) {
            return "No date provided";
        }

        $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
        $lengths = array("60", "60", "24", "7", "4.35", "12", "10");
        $now = time();
        $unix_date = strtotime($date);

        // check validity of date
        if (empty($unix_date)) {
            return "Bad date";
        }

        // is it future date or past date
        if ($now > $unix_date) {
            $difference = $now - $unix_date;
            $tense = "ago";
        } else {
            $difference = $unix_date - $now;
            $tense = "from now";
        }
        for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
            $difference /= $lengths[$j];
        }
        $difference = round($difference);
        if ($difference != 1) {
            $periods[$j].= "s";
        }
        return "$difference $periods[$j] {$tense}";
    }

    public function getSingleRecord($fields, $table, $where) {
        $this->db->select($fields, false);
        $this->db->from($table);
        $this->db->where($where);
        $query = $this->db->get();
        //echo $this->db->last_query();
        if ($query) {
            return $query->row_array();
        } else {
            return false;
        }
    }

    public function getAllRecords($fields, $table, $where, $orderCol, $orderVal) {

        $this->db->select($fields, false);
        $this->db->from($table);
        if (!empty($where)) {
            $this->db->where($where);
        }
        $this->db->order_by($orderCol, $orderVal);
        $query = $this->db->get();
        //echo $this->db->last_query();
        //exit;
        if ($query) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function getAllRecordsByCnt($fields, $table, $where) {
        $this->db->select($fields, false);
        $this->db->from($table);
        if (!empty($where)) {
            $this->db->where($where);
        }
        $query = $this->db->get();
        //echo $this->db->last_query();
        //exit;
        if ($query) {
            return $query->num_rows();
        } else {
            return false;
        }
    }

    public function getAllRecordsByPaginationLimit($fields, $table, $where, $orderCol, $orderVal, $perpage, $limit) {
        $this->db->select($fields, false);
        $this->db->from($table);
        if (!empty($where)) {
            $this->db->where($where);
        }
        $this->db->order_by($orderCol, $orderVal);
        $this->db->limit($perpage, $limit);
        $query = $this->db->get();
//        echo $this->db->last_query();
//        exit;
        if ($query) {
            return $query->result_array();
        } else {
            return false;
        }
    }

    public function getAllRecordsByLimits($fields, $table, $where, $orderCol, $orderVal, $start, $limit) {
        //   print_r($order);exit;
        $this->db->select($fields, false);
        $this->db->from($table);
        $this->db->where($where);
        // $this->db->order_by($order);
        $this->db->order_by($orderCol, $orderVal);
        $this->db->limit($start, $limit);
        $query = $this->db->get();
        // echo $this->db->last_query();
        // exit;
        if ($query) {
            if ($limit == 1) {
                return $query->row_array();
            } else {
                return $query->result_array();
            }
        } else {
            return false;
        }
    }

    public function getAllRecordsByLimit($fields, $table, $where, $orderCol, $orderVal, $limit) {
        //   print_r($order);exit;
        $this->db->select($fields, false);
        $this->db->from($table);
        $this->db->where($where);
        // $this->db->order_by($order);
        $this->db->order_by($orderCol, $orderVal);
        $this->db->limit($limit);
        $query = $this->db->get();
//        echo $this->db->last_query();
//        exit;
        if ($query) {
            if ($limit == 1) {
                return $query->row_array();
            } else {
                return $query->result_array();
            }
        } else {
            return false;
        }
    }

    public function getAllRecordsByJoins($fields, $table1, $table2, $join_type = NULL, $on_join_where, $where, $group = NULL, $order) {

        $this->db->select($fields, false);
        $this->db->from($table1);
        $this->db->join($table2, $on_join_where, $join_type);
        $this->db->where($where);
        if ($group != '') {
            $this->db->group_by($group);
        }
        $this->db->order_by($order);
        $query = $this->db->get();
        //echo $this->db->last_query();
        //exit;
        if ($query) {
            return $query->result_array();
        } else {
            return false;
        }
    }

    public function getAllRecordsByJoinsArr($fields, $table1, $table2, $join_type = NULL, $on_join_where, $where, $group = NULL, $order, $group_id, $group_name, $group_wise) {

        $this->db->select($fields, false);
        $this->db->from($table1);
        $this->db->join($table2, $on_join_where, $join_type);
        $this->db->where($where);
        if ($group != '') {
            $this->db->group_by($group);
        }
        $this->db->order_by($order);
        $query = $this->db->get();
        //echo $this->db->last_query();
        // exit;
        $CRows = array();
        if ($query) {
            $result = $query->result_array();
            if (!empty($result)) {

                foreach ($result as $key => $value) {
                    $CRows[$value[$group_name]][$group_id] = $value[$group_id];
                    $CRows[$value[$group_name]][$group_name] = $value[$group_name];

                    if (array_key_exists($value[$group_name], $CRows) == false) {
                        $CRows[$value[$group_name]][$group_wise] = array();
                    }
                    $CRows[$value[$group_name]][$group_wise][] = $value;
                }
            }
        }
        //echo '<pre>';
        //  print_r($CRows);
        // exit; 
        return $CRows;
    }

    public function addRowinTable($data, $table_name) {
        $this->db->insert($table_name, $data);
        $last_id = $this->db->insert_id();
        return $last_id;
    }

    public function updateRowinTableWhere($data, $table_name, $where) {
        $this->db->where($where);
        $query = $this->db->update($table_name, $data);
        //echo $this->db->last_query();
        // echo "-----";
        //EXIT;
        if ($query) {
            return true;
        } else {
            return false;
        }
    }

    public function getSingleArr($fields, $table, $where, $order) {

        $this->db->select($fields, false);
        $this->db->from($table);
        $this->db->where($where);
        $this->db->order_by($order);

        $query = $this->db->get();
        //echo $this->db->last_query();

        if ($query) {
            $result2 = $query->result_array();
            $flat = iterator_to_array(new RecursiveIteratorIterator(new RecursiveArrayIterator($result2)), 0);
            return $flat;
        } else {
            return false;
        }
    }

    public function get_count($table, $where) {

        $return_count = 0;
        $this->db->select('*', false);
        $this->db->from($table);
        $this->db->where($where);

        $query = $this->db->get();
        //echo $this->db->last_query();
        //exit;
        if ($query->num_rows() > 0) {
            $return_count = $query->num_rows();
        }
        // echo $this->db->last_query();
        // exit;

        return $return_count;
    }

    public function deleteRowinTable($table_name, $where) {
        $this->db->where($where);
        return $this->db->delete($table_name);
    }

    public function getSingleArr_where_in($fields, $table, $colun_name, $where_in, $order) {

        $this->db->select($fields, false);
        $this->db->from($table);
        $this->db->where_in($colun_name, $where_in);
        $this->db->order_by($order);

        $query = $this->db->get();
        //echo $this->db->last_query();
        if ($query) {
            $result2 = $query->result_array();
            $flat = iterator_to_array(new RecursiveIteratorIterator(new RecursiveArrayIterator($result2)), 0);
            $flatStr = @implode(',', $flat);
            return $flatStr;
        } else {
            return false;
        }
    }

    /*     * **********************  Calculating Age  *********************************** */

    function calculateAge($dob, $returnValue) {
        if (!empty($dob)) {
            $birthdate = new DateTime($dob);
            $today = new DateTime('today');

            switch ($returnValue) {

                case "y":
                    $age = $birthdate->diff($today)->$returnValue;
                    break;
                case "m":
                    $age = $birthdate->diff($today)->$returnValue;
                    break;
                case "d":
                    $age = $birthdate->diff($today)->$returnValue;
                    break;
                case "ymd":
                    $age = $birthdate->diff($today)->y . '-' . $birthdate->diff($today)->m . '-' . $birthdate->diff($today)->d;
                    break;
                case "full":

                    $yVal = ($birthdate->diff($today)->y > 1) ? ' years, ' : ' year, ';
                    $mVal = ($birthdate->diff($today)->m > 1) ? ' months, ' : ' month, ';
                    $dVal = ($birthdate->diff($today)->d > 1) ? ' days ' : ' day ';

                    $age = $birthdate->diff($today)->y . $yVal . $birthdate->diff($today)->m . $mVal . $birthdate->diff($today)->d . $dVal;

                    break;
                default:
                    $age = $birthdate->diff($today)->$returnValue;
                    break;
            }

            return $age;
        } else {
            return 0;
        }
    }

    /*     * **************************** Calculate the time diff in hh::mm ********************** */

    function timeDiff($givendate) {
        //  $cTime = time(); // cTime = current time
        $ts = time() - strtotime(str_replace("-", "/", $givendate));

        if ($ts > 31536000)
            $val = round($ts / 31536000, 0) . ' year';
        else if ($ts > 2419200)
            $val = round($ts / 2419200, 0) . ' month';
        else if ($ts > 604800)
            $val = round($ts / 604800, 0) . ' week';
        else if ($ts > 86400)
            $val = round($ts / 86400, 0) . ' day';
        else if ($ts > 3600)
            $val = round($ts / 3600, 0) . ' hour';
        else if ($ts > 60)
            $val = round($ts / 60, 0) . ' minute';
        else
            $val = $ts . ' second';
        if ($val > 1)
            $val .= 's';
        return $val;
    }

    /* total time different function */

    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full)
            $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }

    public function get_encrpty($param) {
        $encrpty = str_replace(array('+', '/'), array('_', '-'), base64_encode(gzdeflate($param)));
        return $encrpty;
    }

    public function get_decrpty($param) {
        $dencrpty = urldecode(gzinflate(base64_decode(str_replace(array('_', '-'), array('+', '/'), $param))));
        return $dencrpty;
    }

    public function base64url_encode($s) {
        return str_replace(array('+', '/'), array('_', '-'), base64_encode($s));
    }

    public function base64url_decode($s) {
        return base64_decode(str_replace(array('_', '-'), array('+', '/'), $s));
    }

}
