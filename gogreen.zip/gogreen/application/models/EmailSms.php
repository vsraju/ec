<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class EmailSms extends CI_Model {

    public $email_template_table = 'tbl_email_templates';

    // Autoloading a system library usin constructor method
    public function __construct() {
        parent::__construct();
    }

    public function time_ago($date) {

        if (empty($date)) {
            return "No date provided";
        }

        $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
        $lengths = array("60", "60", "24", "7", "4.35", "12", "10");
        $now = time();
        $unix_date = strtotime($date);

        // check validity of date
        if (empty($unix_date)) {
            return "Bad date";
        }

        // is it future date or past date
        if ($now > $unix_date) {
            $difference = $now - $unix_date;
            $tense = "ago";
        } else {
            $difference = $unix_date - $now;
            $tense = "from now";
        }
        for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
            $difference /= $lengths[$j];
        }
        $difference = round($difference);
        if ($difference != 1) {
            $periods[$j].= "s";
        }
        return "$difference $periods[$j] {$tense}";
    }

    public function mailSend($to, $message) {
        // echo $to;
        // $this->load->library('phpmailer');
        //$this->load->helper('mail/mailer');

        require_once('mail/class.phpmailer.php');
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPDebug = 3;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "tls";
        $mail->Host = "smtp.mailgun.org";
        $mail->Port = 2525;
        $mail->AddAddress($to);
        $mail->Username = "postmaster@sandbox730a46aade834d96bf846adc68fcbed0.mailgun.org";

        $mail->Password = "97bb0ac4439af572c803b5398b0db4bb";
        $mail->SetFrom('nagamani@innasoft.in', 'Mani');
        $mail->AddReplyTo("nagamani@innasoft.in", "Innasoft");

        $subject = $message['subject'];
        $subject = str_replace("{SITENAME}", $_SERVER['SERVER_NAME'], $subject);

        $header = $this->getMailHeader();
        $content = $message['content'];
        $footer = $this->getMailFooter();
        $template = $header . $content . $footer;

        $mail->Subject = $subject;
        $mail->MsgHTML('sdfasdf ');
        $mail->Send();
    }

    public function mail_send($to, $message) {
        $header = $this->getMailHeader();
        $subject = $message['subject'];
        $subject = str_replace("{SITENAME}", $_SERVER['SERVER_NAME'], $subject);

        $content = $message['content'];
        $footer = $this->getMailFooter();
        //$template = $header . $content . $footer;

        $template = $content;
        // mail library load and config set here
        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";

        // Additional headers host_name 
        //$headers .= 'From: '.$_SERVER['SERVER_NAME'].'' . "\r\n";
        $headers .= 'From: nagamani@innasoft.in' . "\r\n";

        $result = @mail($to, $subject, $template, $headers);

        if ($result) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function setMailHeaderTemplate() {
        $this->db->select('content');
        $this->db->from($this->email_template_table);
        $this->db->where('id', 2);
        $result = $this->db->get();
        $result = $result->row_array();
        return $result['content'];
    }

    public function setMailBodyTemplate($id) {
        $this->db->select('subject,content');
        $this->db->from($this->email_template_table);
        $this->db->where('id', $id);
        $result = $this->db->get();
        //echo $this->db->last_query();
        return $result->row_array();
    }

    public function setMailFooterTemplate() {
        $this->db->select('content');
        $this->db->from($this->email_template_table);
        $this->db->where('id', 3);
        $result = $this->db->get();
        $result = $result->row_array();
        return $result['content'];
    }

    public function getMailHeader() {
        $mailHead = $this->setMailHeaderTemplate();
        $website = str_replace("{WEBSITE}", site_url(), $mailHead);
        $folder = str_replace("{FOLDER}", 'images', $website);
        $logo = str_replace("{LOGO}", 'logo.png', $folder);
        $banner = str_replace("{BANNER}", base_url() . 'images/mail-banner.png', $logo);
        $result = $banner;
        //print_r($result);
        return $result;
    }

    public function getMailFooterOLD() {
        $mailFoot = $this->setMailFooterTemplate();
        $thanks_regards = str_replace("{ADDRESS}", $_SERVER['SERVER_NAME'], $mailFoot);
        $website = str_replace("{WEBSITE}", site_url(), $thanks_regards);
        //print_r($result);
        return $website;
    }

    public function getMailFooter() {
        $mailFoot = $this->setMailFooterTemplate();
        $thanks_regards = str_replace("{YEAR}", date('Y'), $mailFoot);
        $website = str_replace("{WEBSITE}", base_url(), $thanks_regards);
        $url = str_replace("{URL}", '', $website);
        $sitename = str_replace("{SITENAME}", 'My Dream Campus', $url);
        //print_r($result);
        return $sitename;
    }

    public function getRegisterMail($themeid, $name, $username, $profile_id, $password, $url) {
        $mailBody = $this->setMailBodyTemplate($themeid);
        $url = $url;
        $name = str_replace("{NAME}", $name, $mailBody);
        $username = str_replace("{USERNAME}", $username, $name);
        $profile_id = str_replace("{PROFILEID}", $profile_id, $username);
        $password = str_replace("{PASSWORD}", $password, $profile_id);
        $url = str_replace("{URL}", $url, $password);
        $message = str_replace("{WEBSITE}", base_url(), $url);
        return $message;
    }

    public function getRegisterVerifyMail($themeid, $name, $username, $link, $url) {
        $mailBody = $this->setMailBodyTemplate($themeid);
        $url = $url;
        $name = str_replace("{NAME}", $name, $mailBody);
        $link = str_replace("{LINK}", $link, $name);
        // $link_encode = str_replace("{LINKENCODE}", $link, $link);
        $url = str_replace("{URL}", $url, $link);
        $message = str_replace("{WEBSITE}", base_url(), $url);
        return $message;
    }

    public function getActivedMail($themeid, $name, $content) {
        $mailBody = $this->setMailBodyTemplate($themeid);
        $name = str_replace("{NAME}", $name, $mailBody);
        $content = str_replace("{content}", $content, $name);

        return $content;
    }

    public function getForgotPwdMail($themeid, $name, $username, $password, $url) {
        $mailBody = $this->setMailBodyTemplate($themeid);
        $url = $url;
        $name = str_replace("{NAME}", $name, $mailBody);
        $username = str_replace("{USERNAME}", $username, $name);
        $password = str_replace("{PASSWORD}", $password, $username);
        $url = str_replace("{URL}", $url, $password);
        $message = str_replace("{WEBSITE}", base_url(), $url);
        return $message;
    }

    public function getChangePwdMail($themeid, $name, $username, $password, $url) {
        $mailBody = $this->setMailBodyTemplate($themeid);
        $url = $url;
        $name = str_replace("{NAME}", $name, $mailBody);
        $username = str_replace("{USERNAME}", $username, $name);
        $password = str_replace("{PASSWORD}", $password, $username);
        $url = str_replace("{URL}", $url, $password);
        $message = str_replace("{WEBSITE}", base_url(), $url);
        return $message;
    }

    public function send_sms($mobileno, $message) {

        $url = 'http://sms.api.com/api/mt/SendSMS?';
        $params = array(
            'user' => '',
            'password' => '',
            'senderid' => '',
            'Channel' => '',
            'DCS' => '0',
            'flashsms' => '0',
            'number' => '91' . $mobileno,
            'text' => $message . '-' . $_SERVER['SERVER_NAME'],
            'route' => '9',
        );

        $sendUrl = $url . http_build_query($params);
        $Ch = curl_init();
        curl_setopt($Ch, CURLOPT_URL, $sendUrl);
        curl_setopt($Ch, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($Ch);
        curl_close($Ch);
        //print_r($output);exit;
        return $output;
    }

    public function getNotificationMail($themeid, $name, $content) {
        $mailBody = $this->setMailBodyTemplate($themeid);
        $url = $url;
        $name = str_replace("{NAME}", $name, $mailBody);
        $content = str_replace("{content}", $content, $name);

        return $content;
    }

    public function getApplicationRequestMail($themeid, $name, $username, $link, $url) {
        $mailBody = $this->setMailBodyTemplate($themeid);

        $url = $url;
        $name = str_replace("{NAME}", $name, $mailBody);
        $link = str_replace("{LINK}", $link, $name);
        // $link_encode = str_replace("{LINKENCODE}", $link, $link);
        $url = str_replace("{URL}", $url, $link);
        $message = str_replace("{WEBSITE}", base_url(), $url);
        return $message;
    }

}
